# theia-plugin-test
theia-plugin-test Plugin example for Theia.
